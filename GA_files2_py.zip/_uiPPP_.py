#this is '_uiPPP_' file

#rembere to rename the other file '_printJsonName_' to make it work
import json
import os
import re
from ipywidgets import widgets
from IPython.display import display
#from tkinter import *
import tkinter as tk



###///interference_main


import io
import logging
import time
from pathlib import Path

import librosa
import numpy as np
import soundfile

from inference import infer_tool
from inference import slicer
from inference.infer_tool import Svc


logging.getLogger('numba').setLevel(logging.WARNING)
chunks_dict = infer_tool.read_temp("inference/chunks_temp.json")

model_path = "models/twilight-speaking_32khz_28000/G_28000.pth"
config_path = "models/twilight-speaking_32khz_28000/config.json"


# 支持多个wav文件，放在raw文件夹下
clean_names = ['_(Vocals)0']
trans = [10]  # 音高调整，支持正负（半音）
spk_list = ['twilight-speaking']  # 每次同时合成多语者音色
slice_db = -35  # 默认-40，嘈杂的音频可以-30，干声保留呼吸可以-50
wav_format = 'flac'  # 音频输出格式



def run_og_script():
    global spk_list
    global model_path
    global config_path
    global clean_names
    global trans
    
    svc_model = Svc(model_path, config_path)
    infer_tool.mkdir(["raw", "results"])

    infer_tool.fill_a_to_b(trans, clean_names)
    
     
    tmp_clean_names = str(clean_names).split()
    print("LOOK AT THIS: " + str(range(len(tmp_clean_names))))
    
    for trueFileName in range(len(tmp_clean_names)):
        xxx="""
        #tmp_clean_name = clean_name[1:-1]
        print('clean_names2: ' + str(clean_names))
        
    ###    tmp_clean_name = trueFileName[1:-1]
        tmp_clean_name = str(tmp_clean_names[trueFileName])[1:-1]
        print(tmp_clean_name)
    """    
        #for clean_name, tran in zip(clean_names, trans):

        tmp_clean_name = clean_names[trueFileName][1:-1]
        for clean_name, tran in zip(tmp_clean_name, trans):

            #tmp_clean_name = clean_name[1:-1]
            print('clean_names2: ' + str(clean_names))
            
        ###    tmp_clean_name = trueFileName[1:-1]
    ###        tmp_clean_name = str(tmp_clean_names[trueFileName])[1:-1]
    ###        print(tmp_clean_name)

            
            raw_audio_path = f"raw/{tmp_clean_name}"
                

            print('raw_audio_path: ' + str(raw_audio_path))
            raw_audio_path = raw_audio_path.replace("'.wav", ".wav")
        
            if "." not in raw_audio_path:
                raw_audio_path += ".wav"
            infer_tool.format_wav(raw_audio_path)
            wav_path = Path(raw_audio_path).with_suffix('.wav')
            

            
            chunks = slicer.cut(wav_path, db_thresh=slice_db)
            audio_data, audio_sr = slicer.chunks2audio(wav_path, chunks)

            for spk in spk_list:
                audio = []
                for (slice_tag, data) in audio_data:
                    print(f'#=====segment start, {round(len(data) / audio_sr, 3)}s======')
                    length = int(np.ceil(len(data) / audio_sr * svc_model.target_sample))
                    raw_path = io.BytesIO()
                    soundfile.write(raw_path, data, audio_sr, format="wav")
                    raw_path.seek(0)
                    if slice_tag:
                        print('jump empty segment')
                        _audio = np.zeros(length)
                    else:
                        out_audio, out_sr = svc_model.infer(spk, tran, raw_path)
                        _audio = out_audio.cpu().numpy()
                    audio.extend(list(_audio))

                ####res_path = f'./results/{clean_name}_{tran}key_{spk}.{wav_format}'
                res_path = f'./results/{tmp_clean_name}_{tran}key_{spk}.{wav_format}'
                soundfile.write(res_path, audio, svc_model.target_sample, format=wav_format)



###########/////////////////////////////////////////////////////UI code

#get the nested dictionary with models info
import _printJsonName_
#get the wav files list from 'raw' folder
import _printRawList_


grab_the_json = {}
grab_the_json = _printJsonName_.returnJsonNames()
tmp_grab_the_json = grab_the_json
def update_json():
    grab_the_json = _printJsonName_.returnJsonNames()
    tmp_grab_the_json = grab_the_json
update_json()


printThemasterModelsNames_ = 0
printThemasterModelsDic_ = 0


grab_the_raw = _printRawList_.returnRawNames()
def update_raw():
    global grab_the_raw
    grab_the_raw = _printRawList_.returnRawNames()
update_raw()


xxx = """
{'Applejack_38k steps': 

'sub_folder_dir': 'models/Applejack_38k steps', 
'speaker_json_name': 'Applejack', 
'json_full_dir': 'models/Applejack_38k stepsconfig_aj.json', 
'g_model__full_dir': 'models/Applejack_38k steps/G_38000.pth'}
"""


sendSpk = ''
sendGmodel = ''
sendConfig = ''

sendRaw = ''
sendPitch =  0

new_pitch = 0

#options = ['option1', 'option2', 'option3']
#use names from the 'key' valable from the main dictionary
#than use it as the loop to grab them into index list and
#pass it along as a dropdown list

options = [key for key in tmp_grab_the_json]


options_raw = [key for key in grab_the_raw]
#options_raw = [options_raw[1:-1]]

###tmp_options_raw = str(options_raw)
###tmp_options_raw = tmp_options_raw.replace("'", "")
###tmp_options_raw2 = [tmp_options_raw[1:-1]]



options_raw.append(str(options_raw)[1:-1]) #//removes the brackets from the text body of the list





#print(tmp_grab_the_json)

def runDicList():
    theOptions = [key for key in tmp_grab_the_json]
    return theOptions
#options = runDicList()
    



def on_select(v):

    global sendSpk
    global sendGmodel
    global sendConfig
###    print('______')
###    print("Model's Folder: " + v)
    #print(grab_the_json)
    #print(grab_the_json[Applejack_38k_steps])

###    print('spk_list: ' + tmp_grab_the_json[v]['speaker_json_name'])
    ###print(tmp_grab_the_json[v]['sub_folder_dir'])
###    print('model_path: ' + tmp_grab_the_json[v]['g_model__full_dir'])
###    print('config_path: ' + tmp_grab_the_json[v]['json_full_dir'])
    
    sendSpk = str(tmp_grab_the_json[v]['speaker_json_name'])
    sendGmodel = str(tmp_grab_the_json[v]['g_model__full_dir'])
    sendConfig = str(tmp_grab_the_json[v]['json_full_dir'])

def pick_raw(r):
    global sendRaw
    global clean_names
    if not r.startswith("'"): #single wav options lack the quotation marks to pass along
        r = ("'" + str(r) + "'")
    print(r)
    #r = r.replace("'", "")
    sendRaw = (str(r).split(', '))
    clean_names = sendRaw
    print('Selected clean_names: ' + str(clean_names))

def offlineMode():
    
    global sendSpk
    global sendGmodel
    global sendConfig
    global sendRaw
    global sendPitch
    root = tk.Tk()
    root.geometry('300x200')
    
    frame = tk.Frame(root)
    bottomframe = tk.Frame(root)
    bottomframe.pack( side = tk.BOTTOM )
    
    #entry1 = tk.Entry(root, width = 30)
    #entry1.pack()sendPitch())

    #def button_command():
    #    text = entry1.get()
    #    print(text)
    #    #print("test")
    #    return None
    

    
    #drop down
    var = tk.StringVar(value='Select_Model')

    #options = ['option1', 'option2', 'option3']

    dropdown = tk.OptionMenu(root, var, *options, command=on_select)
    dropdown.config(font =("Courier", 14))
    dropdown.pack()
    
    def button_update():
        update_json()
        update_raw()
    
###    masterUpdate = tk.Button(root,text="Refresh_list", command=button_update)
###    masterUpdate.config(font =("Courier", 14))
###    masterUpdate.pack()
    
    var_raw = tk.StringVar(value='Select_Audio')
    dropdown_raw = tk.OptionMenu(root, var_raw, *options_raw, command=pick_raw)
    dropdown_raw.config(font =("Courier", 14))
    dropdown_raw.pack()
    
    
    def b1_def():
        global new_pitch
        global sendPitch
        global clean_names
        #print('1')
        n = -5
        new_pitch = sum((new_pitch, n))
        #print(new_pitch)
        l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
        sendPitch = new_pitch
        
    def b2_def():
        global new_pitch
        global sendPitch
        global clean_names
        #print('2')
        n = -1
        new_pitch = sum((new_pitch, n))
        #print(new_pitch)
        l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
        sendPitch = new_pitch
        
    def b3_def():
        global new_pitch
        global sendPitch
        global clean_names
        #print('3')
        n = 0
        new_pitch = sum((0, 0))
        #print(new_pitch)
        l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
        sendPitch = new_pitch
        
        
    def b4_def():
        global new_pitch
        global sendPitch
        global clean_names
        
        #print('4')
        n = 1
        new_pitch = sum((new_pitch, n))
        #print(new_pitch)
        l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
        sendPitch = new_pitch
        clean_names = sendPitch
        
    def b5_def():
        global new_pitch
        global sendPitch
        global clean_names
        #print('5')
        n = 5
        new_pitch = sum((new_pitch, n))
        #print(new_pitch)
        l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
        sendPitch = new_pitch
        
    
    #new_pitch = 0
    b1 = tk.Button(root, text='<<', command=b1_def)
    b2 = tk.Button(root, text='<', command=b2_def)
    b3 = tk.Button(root, text='Zero', command=b3_def)
    b4 = tk.Button(root, text='>', command=b4_def)
    b5 = tk.Button(root, text='>>', command=b5_def)
    
    b1.config(font =("Courier", 14))
    b2.config(font =("Courier", 14))
    b3.config(font =("Courier", 14))
    b4.config(font =("Courier", 14))
    b5.config(font =("Courier", 14))


    # Create label
    l = tk.Label(root)
    l.config(text = 'Pitch: ' + str(new_pitch), font =("Courier", 14))
    #l.config(font =("Courier", 14))
    
    
    l.pack()
    


    b1.pack(side=tk.LEFT, fill = tk.BOTH, expand = True)
    b2.pack(side=tk.LEFT, fill = tk.BOTH, expand = True) 
    b3.pack(side=tk.LEFT, fill = tk.BOTH, expand = True)
    b4.pack(side=tk.LEFT, fill = tk.BOTH, expand = True) 
    b5.pack(side=tk.LEFT, fill = tk.BOTH, expand = True)
    

    def button_send():
        global sendSpk
        global sendGmodel
        global sendConfig
        global sendRaw
        global sendPitch
#        print('wip')
        sendSpk = sendSpk
        sendGmodel = sendGmodel
        sendConfig = sendConfig

        sendRaw = sendRaw
        sendPitch = sendPitch
        
        print('_____ ___ _____')
        
        print('Apply Speaker:       ' + str(sendSpk))
        print('Apply G_Model:       ' + str(sendGmodel))
        print('Apply Json:          ' + str(sendConfig))
        print('Apply Reference:     ' + str(sendRaw))
        print('Apply Pitch_Shift:   ' + str(sendPitch))
        
        
        global spk_list
        global model_path
        global config_path
        global clean_names
        global trans
        
        
        
    #    fix_clean_names = str(sendRaw)
        #fix_clean_names = re.sub(r'\\\\', '\/', str(fix_clean_names))
    #    fix_clean_names = str(fix_clean_names)
        
        spk_list = [sendSpk]
        model_path = str(sendGmodel)
        config_path = str(sendConfig)
        
        #####clean_names = [fix_clean_names]
        
        trans = [sendPitch]
        
        run_og_script()
        print('__Files converted:   ' + str(sendRaw))
        
    ######    print(fix_clean_names)
        
                
 
        #send rest of the data from here to main py and run script
    
    #masterSend = tk.Button(bottomframe,text="Generate", command=button_send)
    #masterSend.pack(anchor='s')
    
    masterSend = tk.Button(bottomframe,text="Generate", command=button_send)
    masterSend.config(font =("Courier", 14))
    masterSend.pack(fill = tk.BOTH, expand = True)
    
###    def button_send2():
###        print('this button works')
        
    
###    masterSend2 = tk.Button(bottomframe,text="Edit", command=button_send2)
###    masterSend2.config(font =("Courier", 14))
###    masterSend2.pack(fill = tk.BOTH, expand = True)

        
    ###elements go above    
    root.mainloop()


def onlineMode():
    zxcv = 'yes'







# check if the COLAB_ENV variable is present
# this variable is set by default in Colab
if 'COLAB_ENV' in os.environ:
    print('This code is running in Colab')
    onlineMode()
else:
    print('This code is running in offline Python')
    offlineMode()

#########Testing out grabing function has worked##########################

####call out loop by the first layer names inside of the nested dictionary
def printThemasterModelsNames():
    for masterModelsNames in grab_the_json.keys():
        print(masterModelsNames)

####print everything inside the masterModelsDictionary
def printThemasterModelsDic():
    print(grab_the_json)

if (printThemasterModelsNames_): printThemasterModelsNames()
if (printThemasterModelsDic_): printThemasterModelsDic()

#print(grab_the_json)


###########/////////////////////////////////////////////////////UI code

###///interference_main

























