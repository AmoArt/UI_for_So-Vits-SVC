import json
import os
import re

rawFolder = 'raw'
rawList = []

for file in os.listdir(rawFolder):
    #print(files)
    if file.endswith('.wav'):
        #print(file)
        rawList.append(str(file[0:-4]))
        
        
def returnRawNames():
    #return masterModelsDictionary
###    print('Raw List: ' + str(rawList))
    return rawList
returnRawNames()