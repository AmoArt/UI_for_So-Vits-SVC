import json
import os
import re

#this is '_printJsonName_' file

#printTheSmallStuff = True
printTheSmallStuff = False

#folder for stoing 'character model -> json file and models files'
modelsFolderDir = "models"
#print(os.listdir(modelsFolderDir))

microModelsDictionary = {}
masterModelsDictionary = {}
new_dir_values = {}

####call out loop by the first layer names inside of the nested dictionary
printThemasterModelsNames_ = 0
def printThemasterModelsNames():
    for masterModelsNames in masterModelsDictionary.keys():
        print(masterModelsNames)

####print everything inside the masterModelsDictionary
printThemasterModelsDic_ = 0
def printThemasterModelsDic():
    print(masterModelsDictionary)

mMDDirectory = '_MISSING_FILE 1_'
mMDSpeakerName = '_MISSING_FILE 2_'
mMDFolderName = '_MISSING_FILE 3_'
mMDG_model = '_MISSING_FILE 4_'
mMDGJson = '_MISSING_FILE 5_'
mMDGJsonDir = '_MISSING_FILE 6_'

#microModelsDictionary[plain_name] = {'json_full_dir': mMDGJsonDir}
    #'g_model_dir'

#microModelsDictionary[plain_name].update({'json_full_dir': str(mMDGJsonDir)})


def seekJsonSpk(jsonFile):
    if 'spk' in jsonFile:
        for key, value in data['spk'].items():
            #the 'spk' 'key' has the sting value of the model speaker name
            #it needs to be converted+trimmed to str
            #print(key)
            realSpkKey = ''

            #if models has multiple keys in the 'spk', it will run a loop and pick the
            #last key whitch should be the model name 
            for key in data['spk'].items():
                #print(key)
                realSpkKey = str(key)

            collectSpkString = realSpkKey[2:-5]
#            if (printTheSmallStuff): print(str(collectSpkString))

            grabTheSpeaker = str(collectSpkString)

            #this is just 1 or 0 number, ignore it
            #print(value)
            microModelsDictionary[plain_name].update({'speaker_json_name': grabTheSpeaker})
#            print('grabTheSpeaker: ' + grabTheSpeaker)
            return grabTheSpeaker

def g_modelDetect():
    mMDFolderName = str(modelsSubfolderDir).replace(" ", "_")
    mMDG_model = str(file)

#LOOP start
for modelsSubfolderDir in os.listdir(modelsFolderDir):
    #print(modelsSubfolderDir)
    #make full directory 'models/modelsFolderName'
    root_folder = str(modelsFolderDir + '/' + modelsSubfolderDir)
    plain_name = modelsSubfolderDir
    microModelsDictionary[plain_name] = {'sub_folder_dir': root_folder}
    folder_name_str = str(modelsSubfolderDir)
    
    ###################################create the new dictonary based on the list name
    mMDFolderName = str(modelsSubfolderDir).replace(" ", "_")
    #microModelsDictionary[mMDFolderName] = {'sub_folder': folder_name_str}
    sub_folder = folder_name_str

    
#    if (printTheSmallStuff): print(root_folder)
    for root, dirs, files in os.walk(root_folder):
        
        for file in files:
            if file.startswith("G_"):
                #print('g_model: ' + file)
                microModelsDictionary[plain_name].update({'g_model__full_dir': str(root_folder + '/' + file)})
            if file.endswith('.json'):
                #if (printTheSmallStuff): print(file)
                json_file = os.path.abspath(os.path.join(root, file))
      #          print(json_file)
                
                with open(json_file) as json_file:
                    data = json.load(json_file)
                    mMDGJsonDir = str(root + '/' + file)
                    mMDSpeakerName = seekJsonSpk(data)
                    microModelsDictionary[plain_name].update({'json_full_dir': str(mMDGJsonDir)})
                    continue

                

 #                                 'json_full_dir': mMDGJsonDir,
 #                                 'g_model_dir': mMDG_model}
 #               microModelsDictionary[plain_name] = new_dir_values
 #               masterModelsDictionary[mMDFolderName] = microModelsDictionary




#print('new_dir_values: ' + str(new_dir_values))



#####print("___________________________")
#print(microModelsDictionary)
#print(masterModelsDictionary)
if (printThemasterModelsNames_): printThemasterModelsNames()
if (printThemasterModelsDic_): printThemasterModelsDic()



#use TKinter?
def returnJsonNames():
    #return masterModelsDictionary
    return microModelsDictionary
returnJsonNames()



#print("masterModelsDictionary: " + str(masterModelsDictionary))
#####print("___________________________")
#print("microModelsDictionary: " + str(microModelsDictionary))




















